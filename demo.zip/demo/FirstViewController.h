//
//  FirstViewController.h
//  demo
//
//  Created by Puneadmin on 10/10/16.
//  Copyright © 2016 Puneadmin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBManager.h"

@interface FirstViewController : UIViewController<UITextFieldDelegate>{
    
    
     DBManager *databaseReference;
}
@property (weak, nonatomic) IBOutlet UILabel *lblforname;
@property (weak, nonatomic) IBOutlet UILabel *lblforaddress;
@property (weak, nonatomic) IBOutlet UILabel *lblforlocation;
@property (weak, nonatomic) IBOutlet UILabel *lblforpanno;
@property (weak, nonatomic) IBOutlet UITextField *txtforname;
@property (weak, nonatomic) IBOutlet UITextField *txtforaddress;
@property (weak, nonatomic) IBOutlet UITextField *txtforlocation;
@property (weak, nonatomic) IBOutlet UITextField *txtforpanno;
- (IBAction)submitbtnclk:(id)sender;
@end
