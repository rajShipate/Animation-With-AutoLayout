//
//  DBManager.h
//  demo
//
//  Created by Puneadmin on 10/10/16.
//  Copyright © 2016 Puneadmin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface DBManager : NSObject
{
 NSString *databasePath;
}
+(DBManager*)getSharedInstance;
// DATABASE CREATION
-(BOOL)createDB;

// CREATE TABLE
- (void) createTable;

// INSERT DATA INTO DATABASE
- (BOOL) inserData : (NSString *) sql_query;
@end
