//
//  AppDelegate.h
//  demo
//
//  Created by Puneadmin on 10/10/16.
//  Copyright © 2016 Puneadmin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBManager.h"
#import <sqlite3.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>{
    
      DBManager *databaseReference;
    
}

@property (strong, nonatomic) UIWindow *window;


@end

