//
//  DBManager.m
//  demo
//
//  Created by Puneadmin on 10/10/16.
//  Copyright © 2016 Puneadmin. All rights reserved.
//

#import "DBManager.h"
#import <sqlite3.h>
static DBManager *sharedInstance = nil;
static sqlite3 *database = nil;
static sqlite3_stmt *statement = nil;


@implementation DBManager

+(DBManager*)getSharedInstance{
    if (!sharedInstance) {
        sharedInstance = [[super allocWithZone:NULL]init];
        [sharedInstance createDB];
    }
    return sharedInstance;
}


# pragma mark - Create database
-(BOOL)createDB{
    NSString *docsDir;
    NSArray *dirPaths;
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    // Build the path to the database file
    databasePath = [[NSString alloc] initWithString:
                    [docsDir stringByAppendingPathComponent: @"Documents.sqlite"]];
    BOOL isSuccess = YES;
    NSFileManager *filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
        const char *dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
            char *errMsg;
            const char *sql_stmt ="create table if not exists studentsDetail (_id integer PRIMARY KEY AUTOINCREMENT, name text,address text, location text,panno integer)";
            if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                != SQLITE_OK)
            {
                isSuccess = NO;
                NSLog(@"Failed to create table");
            }
            NSLog(@"path: %@",databasePath);
            sqlite3_close(database);
            return  isSuccess;
        }
        else {
            isSuccess = NO;
            NSLog(@"Failed to open/create database");
        }
    }
    return isSuccess;
}
- (void) createTable {
    NSString *createtableSQL =@"CREATE TABLE promo_code (_id integer PRIMARY KEY AUTOINCREMENT, promo_code text, expires_code text,code_value real,currency text,order_id integer, warranty text)";
   // BOOL insert_success = [self inserData: createtableSQL];
//    if (insert_success) {
//        NSLog(@"Success");
//    } else {
//        NSLog(@"failure");
//    }
    
}

- (BOOL) inserData : (NSString *) sql_query {
    
    
    //sqlite3_stmt *statement;
    const char *dbpath = [databasePath UTF8String];
    
    sqlite3_open(dbpath, &database);
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        const char *insert_stmt = [sql_query UTF8String];
        
        sqlite3_prepare_v2(database, insert_stmt, -1, &statement, NULL);
        
        if (sqlite3_step(statement) == SQLITE_DONE)
        {
            NSLog(@"Data added");
        }
        else
        {
            NSLog(@"Data Base error : %s", sqlite3_errmsg(database));
            return NO;
        }
        sqlite3_finalize(statement);
        sqlite3_close(database);
        return  YES;
    }
    else
    {
        return NO;
    }
    return NO;
}

@end
