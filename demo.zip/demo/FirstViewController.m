//
//  FirstViewController.m
//  demo
//
//  Created by Puneadmin on 10/10/16.
//  Copyright © 2016 Puneadmin. All rights reserved.
//

#import "FirstViewController.h"
#import "DBManager.h"
NSUserDefaults *temp;
@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    temp=[[NSUserDefaults standardUserDefaults]valueForKey:@"company"];
    NSLog(@"key1=%@",temp);
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)submitbtnclk:(id)sender {
  
        NSString *insertSQL = [NSString stringWithFormat:@"insert into studentsDetail (name,address,location,panno) values (\"%@\",\"%@\",\"%@\",\"%@\")",self.txtforname.text,self.txtforaddress.text,self.txtforpanno.text,self.txtforlocation.text];
    NSLog(insertSQL);
    databaseReference =[DBManager getSharedInstance];
    [databaseReference inserData:insertSQL];
    
    
    
    
}
# pragma mark - UITextField Delegate Methods
- (void) textFieldDidEndEditing:(UITextField *)textField {
    
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    textField.leftView = paddingView;
    textField.leftViewMode = UITextFieldViewModeAlways;
    
    //     if (textField == self.txtNumberOfUnit) {
    //        [self.textView_problemDesc becomeFirstResponder];
    //    }
    //    else
    //    {
    //        [textField resignFirstResponder];
    //
    //    }
    
    
}

- (void) textFieldDidBeginEditing:(UITextField *)textField {
    
    
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 20)];
    textField.leftView = paddingView;
    textField.leftViewMode = UITextFieldViewModeAlways;
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
        return YES;
}

@end
